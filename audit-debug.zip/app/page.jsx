import AuditChat from "@/components/chat/AuditChat";

export default function HomePage() {
  return <AuditChat />;
}
