def hex_to_rgb(h):
    h = h.lstrip('#')
    return tuple(int(h[i:i+2], 16) for i in (0, 2, 4))

def luminance(rgb):
    def chan(c):
        c = c / 255
        return c/12.92 if c <= 0.03928 else ((c+0.055)/1.055) ** 2.4
    r, g, b = rgb
    return 0.2126*chan(r) + 0.7152*chan(g) + 0.0722*chan(b)

def ratio(hex1, hex2):
    l1 = luminance(hex_to_rgb(hex1))
    l2 = luminance(hex_to_rgb(hex2))
    lighter, darker = max(l1, l2), min(l1, l2)
    return (lighter + 0.05) / (darker + 0.05)

pairs = [
    ("Primary text on page bg", "#E7E9EE", "#0B0E14"),
    ("Muted status label on panel", "#8891A3", "#12151C"),
    ("Button text on primary button", "#12151C", "#7C9CFF"),
    ("Error text on error tint bg", "#F0665A", "#12151C"),  # approximated solid, real bg has 10% alpha over panel
    ("Success/score-high text", "#4FD1A5", "#12151C"),
    ("Amber/score-mid text", "#E8B44D", "#12151C"),
    ("Table row muted value text", "#8891A3", "#12151C"),
    ("Table label text", "#C4C9D4", "#12151C"),
    ("Placeholder/input text", "#E7E9EE", "#12151C"),
    ("Error banner text on page bg", "#F0665A", "#0B0E14"),
]

print(f"{'Pair':45} {'Ratio':>8}  {'AA-normal(4.5)':>15} {'AA-large(3.0)':>15}")
for label, fg, bg in pairs:
    r = ratio(fg, bg)
    print(f"{label:45} {r:8.2f}  {'PASS' if r>=4.5 else 'FAIL':>15} {'PASS' if r>=3.0 else 'FAIL':>15}")
