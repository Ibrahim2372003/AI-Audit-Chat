# AUDIT.md — Accessibility & performance pass

## What this document is, and isn't

This sandbox has no Chromium binary (confirmed by trying: `apt-get install
chromium-browser` pulls in `snapd`, whose `.deb` 404s against this
environment's package mirror) and no deployed preview URL. That rules out
running **real Lighthouse** or **real WAVE** here — both need an actual
browser. I'm not fabricating scores for either.

What follows is everything that **is** genuinely verifiable without a
browser — real math, a real production build, and a real accessibility
rule engine (axe-core) run via jsdom — plus fixes to the actual production
files, plus an exact script for you to run the parts that need a real
browser and get real numbers.

---

## 1. Fixes made (production code)

| File | Change | Why |
|---|---|---|
| `components/chat/AuditChat.tsx`, `app/page.jsx` | Outer `<div>` → `<main>` | No landmark region existed; screen-reader users had no way to jump to main content |
| same | Added visually-hidden `<h1>SEO audit chat</h1>` | Page had an `<h2>` (in `EmptyState`) with no `<h1>` above it — broken heading hierarchy |
| same | `aria-live="polite"` on assistant text parts | AI-specific requirement from the brief: streamed output wasn't announced to screen readers at all before this |
| same | Loading/streaming state now shows a real `<button type="button" onClick={() => stop()}>Stop</button>` instead of a `disabled` Send button | AI-specific requirement: a disabled button is not "keyboard-reachable" in any useful sense — there was no way to cancel an in-flight request before this |
| same | Input and both buttons: added `focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2` | Previously the input only changed border *color* on focus (a color-only indicator fails WCAG 2.4.7 in spirit — needs a non-color cue too); the Send button had **no focus style at all** |

No visual/layout change beyond the Stop-button swap (which replaces a
previously-useless disabled button with a functional one — same slot, same
size).

## 2. Color contrast — real math, not a Lighthouse screenshot

Computed with the actual WCAG relative-luminance formula against every
foreground/background pair used in the app (script: `contrast.py`,
included below for reproducibility):

| Pair | Ratio | AA normal (4.5) | AA large (3.0) |
|---|---|---|---|
| Primary text on page bg | 15.90 | PASS | PASS |
| Muted status label on panel | 5.76 | PASS | PASS |
| Button text on primary button | 7.01 | PASS | PASS |
| Error text on error tint bg | 5.87 | PASS | PASS |
| Score-high (green) text | 9.56 | PASS | PASS |
| Score-mid (amber) text | 9.63 | PASS | PASS |
| Table value text (muted) | 5.76 | PASS | PASS |
| Table label text | 11.00 | PASS | PASS |
| Input text | 15.04 | PASS | PASS |
| Error banner text on page bg | 6.21 | PASS | PASS |

All ten pass AA. This covers the color math; it does **not** cover
rendered contrast under real browser color management, subpixel
anti-aliasing, or any color introduced by browser extensions/dark-mode
overrides — a real WAVE/axe browser run is still worth doing.

```python
def hex_to_rgb(h):
    h = h.lstrip('#')
    return tuple(int(h[i:i+2], 16) for i in (0, 2, 4))

def luminance(rgb):
    def chan(c):
        c = c / 255
        return c/12.92 if c <= 0.03928 else ((c+0.055)/1.055) ** 2.4
    r, g, b = rgb
    return 0.2126*chan(r) + 0.7152*chan(g) + 0.0722*chan(b)

def ratio(hex1, hex2):
    l1, l2 = luminance(hex_to_rgb(hex1)), luminance(hex_to_rgb(hex2))
    lighter, darker = max(l1, l2), min(l1, l2)
    return (lighter + 0.05) / (darker + 0.05)
```

## 3. Structural accessibility — real axe-core run, before/after

Added `components/chat/__tests__/AuditChat.a11y.test.tsx`, running the
actual `axe-core` rule engine (not a mock, not WAVE — a different but
comparable industry-standard engine) against the real `AuditChat`
component via jsdom, across empty/streaming/error states.

**Important limitation, stated plainly:** jsdom has no layout or paint
engine. axe's color-contrast, and anything depending on actual visual
rendering, comes back "incomplete" rather than pass/fail in this
environment — that's why section 2 exists as a separate, real check.
What this run **does** reliably catch: missing landmarks, invalid/missing
ARIA, missing form labels, heading order, duplicate IDs — the structural
half of an audit.

**Before** (prior to this task's fixes — reconstructed by re-running axe
against the pre-fix component, i.e. `<div>` root, no `<h1>`, no
`aria-live`, disabled-only busy button, color-only focus):
```
✗ landmark-one-main: Document should have one main landmark
✗ page-has-heading-one: Page must contain a level-one heading
```
(Both are real axe-core rule IDs; re-run yourself with the pre-fix JSX to
reproduce exactly this output — I verified it by temporarily reverting the
component and re-running the same test file.)

**After:**
```
✓ components/chat/__tests__/AuditChat.a11y.test.tsx (3 tests)
  ✓ empty state has no axe violations
  ✓ streaming state (tool call + busy input) has no axe violations
  ✓ error state (with retry button) has no axe violations
```

## 4. Real production build — bundle output

`npm run build` runs clean (Next 16.3.1 / Turbopack, real compile, real
type-check, real static generation — not simulated):

```
Route (app)
┌ ○ /
├ ○ /_not-found
├ ƒ /api/audit-chat
└ ○ /motion-demo

○  (Static)   prerendered as static content
ƒ  (Dynamic)  server-rendered on demand
```

Total static JS shipped from `.next/static/chunks/*.js`: **868 KB**
uncompressed, combined across both `/` and `/motion-demo` (this Next/
Turbopack version doesn't print the classic per-route "First Load JS"
table, so this is a combined figure, not a clean per-route breakdown —
flagging the imprecision rather than presenting it as more exact than it
is). No obviously oversized dependency stood out in a manual scan of
`package.json` — no chart/animation/date libraries pulled in that aren't
used.

## 5. What still needs a real browser — do this yourself, exact steps

I can't produce these. Run them against your deployed preview and paste
the output back if you want me to interpret or act on it:

**Lighthouse (mobile):**
```
1. Open the deployed preview URL in Chrome
2. DevTools → Lighthouse tab → Mobile preset → check Performance + Accessibility → Analyze
   (or CLI: npx lighthouse <url> --preset=perf --form-factor=mobile --screenEmulation.mobile --view)
3. Screenshot the summary (the 4 circular scores) for this doc
```

**WAVE:**
```
1. Install the WAVE browser extension
2. Open the deployed preview, run WAVE on / (empty state) and mid-conversation
3. Screenshot the errors/alerts panel; paste the specific text if anything
   other than 0 errors appears
```

**Keyboard-only pass (do this manually, no tool needed):**
```
1. Tab from the top of the page — confirm focus lands visibly on the
   input first, then Send/Stop
2. Type a URL, hit Enter — confirm you can Tab to Stop while it's
   streaming and Enter/Space activates it
3. Trigger an error (or use ?sabotage=429 from the earlier failure-testing
   task) — confirm Tab reaches "Retry last message" and it's operable
4. Confirm nothing requires a mouse at any point in this flow
```

If any of these three turn up something real, send me the output —
Lighthouse's JSON, WAVE's error list, or what specifically broke in the
keyboard pass — and I'll fix the actual cause rather than guess at one.

## 6. Honest scorecard against this task's criteria

| Criterion | Status |
|---|---|
| Lighthouse mobile 90+ (perf & a11y) | **Not measured** — no browser available here; steps above given to get real numbers |
| Zero WAVE errors | **Not measured** — same reason; axe-core (comparable engine) is clean on everything it can check without a browser |
| Primary flow completable by keyboard | Built for (real `<button>`s throughout, visible focus rings added, no keyboard traps introduced) but **not manually walked in a real browser** — do the 4-step pass above to confirm |
| `AUDIT.md` shows measurable deltas | Contrast ratios and axe-core results above are real before/after; Lighthouse/WAVE deltas are the one piece missing a number until you run them |
