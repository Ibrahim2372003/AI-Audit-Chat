import '@testing-library/jest-dom/vitest';
import { cleanup } from '@testing-library/react';
import { afterEach, expect, vi } from 'vitest';
import { toHaveNoViolations } from 'vitest-axe/matchers';

// jsdom doesn't implement scrollIntoView; AuditChat calls it in a real
// useEffect for auto-scroll. Stubbing it here is a test-environment
// concern, not a production code change.
Element.prototype.scrollIntoView = vi.fn();

// vitest-axe@0.1.0's own `vitest-axe/extend-expect` entry point ships as an
// empty file (checked: 0 lines on disk) — wiring the matcher directly from
// `vitest-axe/matchers` instead of relying on that broken import.
expect.extend({ toHaveNoViolations });

afterEach(() => {
  cleanup();
});
